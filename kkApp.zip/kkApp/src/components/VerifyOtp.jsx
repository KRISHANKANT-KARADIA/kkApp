import React from 'react'

import log1 from '../assets/loginImg/1.png'
import { Link } from 'react-router-dom'


const VerifyOtp = () => {
    return (

        <div className="outstation_page">
            <div className="outstation_page_left">
                <div className="outstation_page_header">



                    <div className="login_box">
                        {/* <div className="loginImg"></div> */}

                        <div id="carouselExampleIndicators" className="carousel slide">
                            <div className="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={0} className="active" aria-current="true" aria-label="Slide 1" />
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={1} aria-label="Slide 2" />
                                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={2} aria-label="Slide 3" />
                            </div>
                            <div className="carousel-inner">
                                <div className="carousel-item active">
                                    {/* <img src="https://images.pexels.com/photos/927451/pexels-photo-927451.jpeg?auto=compress&cs=tinysrgb&w=600" className="d-block w-100" alt="..."  /> */}
                                    <img src={log1} className="d-block w-100" alt="..." />

                                </div>
                                <div className="carousel-item">
                                    <img src={log1} className="d-block w-100" alt="..." />

                                    {/* <img src="https://images.pexels.com/photos/585419/pexels-photo-585419.jpeg?auto=compress&cs=tinysrgb&w=600" className="d-block w-100" alt="..." /> */}
                                </div>
                                <div className="carousel-item">
                                    <img src={log1} className="d-block w-100" alt="..." />

                                    {/* <img src="https://images.pexels.com/photos/1181715/pexels-photo-1181715.jpeg?auto=compress&cs=tinysrgb&w=600" className="d-block w-100" alt="..." /> */}
                                </div>
                            </div>
                            <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                <span className="carousel-control-prev-icon" aria-hidden="true" />
                                <span className="visually-hidden">Previous</span>
                            </button>
                            <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                <span className="carousel-control-next-icon" aria-hidden="true" />
                                <span className="visually-hidden">Next</span>
                            </button>
                        </div>


                    </div>

                    <div className="login_box2">
                        <div className="loginImg2"></div>
                        <h6 className="text-muted">Verify OTP</h6>
                        <span>OTP Sent to +91 9559 888 225</span>
                        <Link to="#">Change Number</Link>
                    </div>


                    <div className="card-body text-center">
                        {/* Title */}

                        {/* Phone Input */}
                        <form>
                            <div className="d-flex justify-content-center gap-3 py-3 ">
                                <div className="border rounded p-3">2</div>
                                <div className="border rounded p-3">2</div>
                                <div className="border rounded p-3">2</div>
                                <div className="border rounded p-3">2</div>
                            </div>


                            {/* Login Button */}
                            <button type="submit" className="btn login-btn w-100"> <Link to='/VerifyOtp' className='text-white text-decoration-none'>Verify OTP</Link></button>
                        </form>
                        {/* Terms & Conditions */}
                        <p className="terms-text mt-4">
                            By logging in, you agree to the <br />
                            <a href="#" className="text-decoration-none">Terms &amp; Conditions</a>
                        </p>
                    </div>







                    {/* <div className="login-container">
          <div className="card shadow-sm">
  
            <img src="https://via.placeholder.com/400x200" className="card-img-top" alt="Technician Working" />

          </div>
        </div> */}
                </div>
            </div>









            <div className="car_outstation_page_right">
                <div className="container">
                    <div className="car_outstation_page_right_content">
                        <h1>Ride your Cab</h1>
                        <p>book in depart hour</p>
                    </div>
                </div>
            </div>
        </div>


    )
}

export default VerifyOtp