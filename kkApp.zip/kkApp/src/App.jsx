import './App.css'
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import '../node_modules/bootstrap/dist/js/bootstrap.bundle.js'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Login from './components/Login.jsx'
import VerifyOtp from './components/VerifyOtp.jsx'



function App() {

  return (
    <>


      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />}></Route>
          <Route path='/VerifyOtp' element={<VerifyOtp />} />
        </Routes>
      </BrowserRouter>




    </>
  )
}

export default App

